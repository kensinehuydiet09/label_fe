import React from 'react';

const AdminRoutes = () => {
    return (
        <div>
            
        </div>
    );
};

export default AdminRoutes;